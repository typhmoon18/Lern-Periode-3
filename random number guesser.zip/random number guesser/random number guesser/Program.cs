﻿using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace random_number_guesser
{
    internal class Program
    {
        class Punktesystem
        {
            private int points;

            public Punktesystem()
            {
                points = 0;
            }

            public void PunkteHinzufügen(int pointsplus)
            {
                points += pointsplus;
            }

            public void PunkteAbziehen(int pointsminus)
            {
                points -= pointsminus;

               
                if (points < 0)
                {
                    points = 0;
                }
            }

            public int AktuellePunkteAbrufen()
            {
                return points;
            }
        }

        class Programm
        {
            static void Main()
            {
                Punktesystem punktesystem = new Punktesystem();

                punktesystem.PunkteHinzufügen(10);
                Console.WriteLine("Aktuelle Punkte: " + punktesystem.AktuellePunkteAbrufen());

                punktesystem.PunkteAbziehen(5);
                Console.WriteLine("Aktuelle Punkte: " + punktesystem.AktuellePunkteAbrufen());
            }
        }
        static void Main(string[] args)
        {

        
            
            Console.WriteLine("Pick a random number between 1 and 10");

            Random rnd = new Random();
            int number = rnd.Next(1, 10);

            int userinput = Convert.ToInt32((Console.ReadLine()));


            if (userinput == number)
                Console.WriteLine("Hell yeah ur right");

            if (userinput != number)
                Console.WriteLine("Ur not quiet right");

            Console.WriteLine("I am now going to give you a few hints:");

            while (true)
            {
                if (userinput < number)
                {
                    Console.WriteLine("The number is higher");
                }
                if (userinput > number)
                {
                    Console.WriteLine("The number is lower");
                }
                Console.WriteLine("Now try to guess the Number again");
                int userinput2 = Convert.ToInt32((Console.ReadLine()));

                if (userinput2 != number)
                {
                    Console.WriteLine("Lets try again");
                }
                if (userinput2 == number)
                {
                    Console.WriteLine("Very good you won.");
                    break;

                }
               
            }




        }




    }
    
    

}        
    
